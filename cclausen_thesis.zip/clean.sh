rm *.aux; rm *.bbl; rm *.blg; rm *.log; rm *.out; rm *.toc;
